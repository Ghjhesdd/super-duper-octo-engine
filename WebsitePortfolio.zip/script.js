// تأثير عند التحويم فوق صور المشاريع لإظهار الوصف
document.querySelectorAll('.project-images img').forEach(image => {
    image.addEventListener('mouseover', () => {
        image.style.transform = 'scale(1.1)';
        image.style.transition = 'transform 0.3s';
    });
    image.addEventListener('mouseout', () => {
        image.style.transform = 'scale(1)';
    });
});

// تأثير عند الضغط على زر التنزيل
document.querySelectorAll('.download-button').forEach(button => {
    button.addEventListener('mousedown', () => {
        button.style.transform = 'scale(0.95)';
    });
    button.addEventListener('mouseup', () => {
        button.style.transform = 'scale(1)';
    });
});

// إضافة تأثير عند تحميل الصفحة
window.addEventListener('load', () => {
    document.body.style.opacity = '1';
    document.body.style.transition = 'opacity 1s';
});